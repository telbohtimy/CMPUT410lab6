$(document).ready(function(){
	$('#addLink').click(function(){
		$('.popBackground,.popWindow').show();
	});
	$('.cancelBtn').click(function(){
		$('.popBackground,.popWindow').hide();
	});
});